-- imported data using 'Table Data Import Wizard'

SELECT * from `bajaj auto`;
SELECT * from `eicher motors`;
SELECT * from `hero motocorp`;
SELECT * from `infosys`;
SELECT * from `tcs`;
SELECT * from `tvs motors`;

-- task 1: Creating  new tables named 'bajaj1','eicher1','infosys1','hero1','tcs1','tvs1' containing the date,
-- close price, 20 Day MA and 50 Day MA.

									-- creating 'bajaj1'

create table bajaj_temp as
select `Date`, `Close Price` from `bajaj auto`;

alter table bajaj_temp change column `Date` datestring varchar(20);
alter table bajaj_temp add column `Date` DATE;
update bajaj_temp set `Date`= STR_TO_DATE(`datestring`, '%d-%M-%Y');

SELECT * from bajaj_temp
order by `Date` ASC;

ALTER TABLE bajaj_temp
drop column datestring;

create table bajaj_temp2
WITH CTE_bajaj_temp (`Date`, `Close Price`, RowNumber, `20 DAY MA`, `50 DAY MA`)
AS
(
SELECT `Date`,
       `Close Price`,
       ROW_NUMBER() OVER (ORDER BY `Date` ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 DAY MA`,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 DAY MA`
FROM   bajaj_temp
) 
SELECT `Date`,
       RowNumber,
       `Close Price`,
       IF(RowNumber > 19, `20 DAY MA`, NULL) `20 DAY MA`,
       IF(RowNumber > 49, `50 DAY MA`, NULL) `50 DAY MA`,
       CASE
          WHEN RowNumber > 49 AND (`20 DAY MA` > `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))< (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'BUY'
          WHEN RowNumber > 49 AND (`20 DAY MA` < `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))> (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'SELL'
          ELSE 'HOLD'
       END as 'Signal'
FROM   CTE_bajaj_temp  ORDER BY `Date`;

create table bajaj1 as
select `Date`, `Close Price`,`20 DAY MA`,`50 DAY MA` from bajaj_temp2;
select * from bajaj1;


								-- creating 'eicher1'
                                
create table eicher_temp as
select `Date`, `Close Price` from `eicher motors`;

alter table eicher_temp change column `Date` datestring varchar(20);
alter table eicher_temp add column `Date` DATE;
update eicher_temp set `Date`= STR_TO_DATE(`datestring`, '%d-%M-%Y');

SELECT * from eicher_temp
order by `Date` ASC;

ALTER TABLE eicher_temp
drop column datestring;

create table eicher_temp2
WITH CTE_eicher_temp (`Date`, `Close Price`, RowNumber, `20 DAY MA`, `50 DAY MA`)
AS
(
SELECT `Date`,
       `Close Price`,
       ROW_NUMBER() OVER (ORDER BY `Date` ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 DAY MA`,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 DAY MA`
FROM   eicher_temp
) 
SELECT `Date`,
       RowNumber,
       `Close Price`,
       IF(RowNumber > 19, `20 DAY MA`, NULL) `20 DAY MA`,
       IF(RowNumber > 49, `50 DAY MA`, NULL) `50 DAY MA`,
       CASE
          WHEN RowNumber > 49 AND (`20 DAY MA` > `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))< (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'BUY'
          WHEN RowNumber > 49 AND (`20 DAY MA` < `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))> (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'SELL'
          ELSE 'HOLD'
       END as 'Signal'
FROM   CTE_eicher_temp  ORDER BY `Date`;

create table eicher1 as
select `Date`, `Close Price`,`20 DAY MA`,`50 DAY MA` from eicher_temp2;
select * from eicher1;


								-- creating 'hero1'
                                
create table hero_temp as
select `Date`, `Close Price` from `hero motocorp`;

alter table hero_temp change column `Date` datestring varchar(20);
alter table hero_temp add column `Date` DATE;
update hero_temp set `Date`= STR_TO_DATE(`datestring`, '%d-%M-%Y');

SELECT * from hero_temp
order by `Date` ASC;

ALTER TABLE hero_temp
drop column datestring;

create table hero_temp2
WITH CTE_hero_temp (`Date`, `Close Price`, RowNumber, `20 DAY MA`, `50 DAY MA`)
AS
(
SELECT `Date`,
       `Close Price`,
       ROW_NUMBER() OVER (ORDER BY `Date` ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 DAY MA`,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 DAY MA`
FROM   hero_temp
) 
SELECT `Date`,
       RowNumber,
       `Close Price`,
       IF(RowNumber > 19, `20 DAY MA`, NULL) `20 DAY MA`,
       IF(RowNumber > 49, `50 DAY MA`, NULL) `50 DAY MA`,
       CASE
          WHEN RowNumber > 49 AND (`20 DAY MA` > `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))< (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'BUY'
          WHEN RowNumber > 49 AND (`20 DAY MA` < `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))> (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'SELL'
          ELSE 'HOLD'
       END as 'Signal'
FROM   CTE_hero_temp  ORDER BY `Date`;

create table hero1 as
select `Date`, `Close Price`,`20 DAY MA`,`50 DAY MA` from hero_temp2;
select * from hero1;


								-- creating 'tcs1'
                                
create table tcs_temp as
select `Date`, `Close Price` from `tcs`;

alter table tcs_temp change column `Date` datestring varchar(20);
alter table tcs_temp add column `Date` DATE;
update tcs_temp set `Date`= STR_TO_DATE(`datestring`, '%d-%M-%Y');

SELECT * from tcs_temp
order by `Date` ASC;

ALTER TABLE tcs_temp
drop column datestring;

create table tcs_temp2
WITH CTE_tcs_temp (`Date`, `Close Price`, RowNumber, `20 DAY MA`, `50 DAY MA`)
AS
(
SELECT `Date`,
       `Close Price`,
       ROW_NUMBER() OVER (ORDER BY `Date` ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 DAY MA`,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 DAY MA`
FROM   tcs_temp
) 
SELECT `Date`,
       RowNumber,
       `Close Price`,
       IF(RowNumber > 19, `20 DAY MA`, NULL) `20 DAY MA`,
       IF(RowNumber > 49, `50 DAY MA`, NULL) `50 DAY MA`,
       CASE
          WHEN RowNumber > 49 AND (`20 DAY MA` > `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))< (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'BUY'
          WHEN RowNumber > 49 AND (`20 DAY MA` < `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))> (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'SELL'
          ELSE 'HOLD'
       END as 'Signal'
FROM   CTE_tcs_temp  ORDER BY `Date`;

create table tcs1 as
select `Date`, `Close Price`,`20 DAY MA`,`50 DAY MA` from tcs_temp2;
select * from tcs1;


								-- creating 'tvs1'
                                
create table tvs_temp as
select `Date`, `Close Price` from `tvs motors`;

alter table tvs_temp change column `Date` datestring varchar(20);
alter table tvs_temp add column `Date` DATE;
update tvs_temp set `Date`= STR_TO_DATE(`datestring`, '%d-%M-%Y');

SELECT * from tvs_temp
order by `Date` ASC;

ALTER TABLE tvs_temp
drop column datestring;

create table tvs_temp2
WITH CTE_tvs_temp (`Date`, `Close Price`, RowNumber, `20 DAY MA`, `50 DAY MA`)
AS
(
SELECT `Date`,
       `Close Price`,
       ROW_NUMBER() OVER (ORDER BY `Date` ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 DAY MA`,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 DAY MA`
FROM   tvs_temp
) 
SELECT `Date`,
       RowNumber,
       `Close Price`,
       IF(RowNumber > 19, `20 DAY MA`, NULL) `20 DAY MA`,
       IF(RowNumber > 49, `50 DAY MA`, NULL) `50 DAY MA`,
       CASE
          WHEN RowNumber > 49 AND (`20 DAY MA` > `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))< (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'BUY'
          WHEN RowNumber > 49 AND (`20 DAY MA` < `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))> (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'SELL'
          ELSE 'HOLD'
       END as 'Signal'
FROM   CTE_tvs_temp  ORDER BY `Date`;

create table tvs1 as
select `Date`, `Close Price`,`20 DAY MA`,`50 DAY MA` from tvs_temp2;
select * from tvs1;


								-- creating 'infosys1'
                                
create table infosys_temp as
select `Date`, `Close Price` from `infosys`;

alter table infosys_temp change column `Date` datestring varchar(20);
alter table infosys_temp add column `Date` DATE;
update infosys_temp set `Date`= STR_TO_DATE(`datestring`, '%d-%M-%Y');

SELECT * from infosys_temp
order by `Date` ASC;

ALTER TABLE infosys_temp
drop column datestring;

create table infosys_temp2
WITH CTE_infosys_temp (`Date`, `Close Price`, RowNumber, `20 DAY MA`, `50 DAY MA`)
AS
(
SELECT `Date`,
       `Close Price`,
       ROW_NUMBER() OVER (ORDER BY `Date` ASC) RowNumber,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 19 PRECEDING) AS `20 DAY MA`,
       AVG(`Close Price`) OVER (ORDER BY `Date` ASC ROWS 49 PRECEDING) AS `50 DAY MA`
FROM   infosys_temp
) 
SELECT `Date`,
       RowNumber,
       `Close Price`,
       IF(RowNumber > 19, `20 DAY MA`, NULL) `20 DAY MA`,
       IF(RowNumber > 49, `50 DAY MA`, NULL) `50 DAY MA`,
       CASE
          WHEN RowNumber > 49 AND (`20 DAY MA` > `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))< (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'BUY'
          WHEN RowNumber > 49 AND (`20 DAY MA` < `50 DAY MA`) AND (LAG(`20 DAY MA`) OVER(ORDER BY DATE))> (LAG(`50 DAY MA`) OVER(ORDER BY DATE)) THEN 'SELL'
          ELSE 'HOLD'
       END as 'Signal'
FROM   CTE_infosys_temp  ORDER BY `Date`;

create table infosys1 as
select `Date`, `Close Price`,`20 DAY MA`,`50 DAY MA` from infosys_temp2;
select * from infosys1;



-- task 2: Creating a master table containing the date and close price of all the six stocks.


create table `master table` as 
select `Date`,`close price` from bajaj1;
alter table `master table` change `close price` `Bajaj` char(20);
alter table `master table` add TCS varchar(20);
alter table `master table` add TVS varchar(20);
alter table `master table` add Infosys varchar(20);
alter table `master table` add Eicher varchar(20);
alter table `master table` add Hero varchar(20);


UPDATE `master table` m1 INNER JOIN tcs1 t1 ON m1.`Date` = t1.`Date` SET m1.TCS = t1.`close price`;
UPDATE `master table` m1 INNER JOIN tvs1 t1 ON m1.`Date` = t1.`Date` SET m1.TVS = t1.`close price`;
UPDATE `master table` m1 INNER JOIN infosys1 t1 ON m1.`Date` = t1.`Date` SET m1.Infosys = t1.`close price`;
UPDATE `master table` m1 INNER JOIN eicher1 t1 ON m1.`Date` = t1.`Date` SET m1.Eicher = t1.`close price`;
UPDATE `master table` m1 INNER JOIN hero1 t1 ON m1.`Date` = t1.`Date` SET m1.Hero = t1.`close price`;

select * from `master table`;

-- task 3: Use the table created in Part(1) to generate buy and sell signal.
-- Store this in another table named 'bajaj2'. Perform this operation for all stocks.

			-- creating 'bajaj2'
            
create table bajaj2 as
select `Date`, `Close Price`,`Signal` from bajaj_temp2;
select * from bajaj2;

			-- creating 'eicher2'
            
create table eicher2 as
select `Date`, `Close Price`,`Signal` from eicher_temp2;
select * from eicher2;

			-- creating 'infosys2'
            
create table infosys2 as
select `Date`, `Close Price`,`Signal` from infosys_temp2;
select * from infosys2;

			-- creating 'tcs2'
            
create table tcs2 as
select `Date`, `Close Price`,`Signal` from tcs_temp2;
select * from tcs2;

			-- creating 'tvs2'
            
create table tvs2 as
select `Date`, `Close Price`,`Signal` from tvs_temp2;
select * from tvs2;

			-- creating 'hero2'
            
create table hero2 as
select `Date`, `Close Price`,`Signal` from hero_temp2;
select * from hero2;


-- task 4: Creating a User defined function, that takes the date as input and returns the signal for
-- that particular day (Buy/Sell/Hold) for the Bajaj stock.


  DROP FUNCTION IF EXISTS test;
   
DELIMITER $$
CREATE FUNCTION test (day_Q date)
returns VARCHAR(4)
 DETERMINISTIC
BEGIN
	DECLARE SIG VARCHAR(4);
	SELECT `Signal` INTO SIG FROM bajaj2 WHERE bajaj2.Date= day_Q;
	RETURN SIG;
END; $$

select test('2015-05-18');     -- input any date
